function route(pathname){
    if (pathname == '/insert' && req.method == "POST"){
        var str = "";//接收数据用
        req.on('data',function(data){
            str += data;
        });
        req.on('end', () => {
            
            crudService.desc("t_assets").then(tableInfo => {
		var obj = JSON.parse(str)
                let table = new Table(tableInfo.tableName, obj.account, tableInfo.valueFields, tableInfo.optional);
		
                let fieldNames = tableInfo.valueFields.split(',');
                let fieldValues = obj["values"].split(',');

                if (fieldNames.length !== fieldValues.length) {
                    throw new Error(`unmatch number of fields, expected ${fieldNames.length} but got ${fieldValues.length}`);
                }

                let entry = new Entry();
                for (let index in fieldNames) {
                    entry.put(fieldNames[index], fieldValues[index]);
                }

                crudService.insert(table, entry).then(value=>{
			console.log(value)
			if(value == "1"){
				console.log("insert successfuuly")	
			}	
		});
            });
        })
    }

    if (pathname == '/select' && req.method == "POST"){
	var ans
        var str = "";//接收数据用
        req.on('data',function(data){
            str += data;
        });
        req.on('end', () => {
            var obj = JSON.parse(str)
            let tableName = "t_assets";
            let key = obj["account"];
            let condition = obj["condition"];

            crudService.desc(tableName).then(tableInfo => {
		
                let table = new Table("t_assets", obj.account, tableInfo.valueFields, tableInfo.optional);
                crudService.select(table, ret).then(value=>{
			ans = value[0]["money"]
			res.end(ans)
		})
		
            });
        });
    }

    if (pathname == '/update' && req.method == "POST"){
        var str = "";//接收数据用
        req.on('data',function(data){
            str += data;
        });
        req.on('end', () => {
            
            crudService.desc("t_assets").then(tableInfo => {
		var obj = JSON.parse(str)
		var new_ret = new Condition()
		new_ret.eq("account", obj.account)
                let table = new Table(tableInfo.tableName, obj.account, tableInfo.valueFields, tableInfo.optional);
		
                let fieldNames = tableInfo.valueFields.split(',');
                let fieldValues = obj["values"].split(',');

                if (fieldNames.length !== fieldValues.length) {
                    throw new Error(`unmatch number of fields, expected ${fieldNames.length} but got ${fieldValues.length}`);
                }

                let entry = new Entry();
                for (let index in fieldNames) {
                    entry.put(fieldNames[index], fieldValues[index]);
                }

                crudService.update(table, entry, ret).then(value=>{
			console.log(value)
			if(value != "0"){
				console.log("update successfuuly")	
			}	
		});
            });
        })
    }

    if (pathname == '/transfer' && req.method == "POST"){
        var str = "";//接收数据用
        req.on('data',function(data){
            str += data;
        });
        req.on('end', () => {
            
            crudService.desc("t_assets").then(tableInfo => {
		var obj = JSON.parse(str)
		var new_ret_from = new Condition()
		new_ret_from.eq("account", obj.from_account)
		var new_ret_to = new Condition()
		new_ret_to.eq("account", obj.to_account)
                let table = new Table(tableInfo.tableName, obj.from_account, tableInfo.valueFields, tableInfo.optional);
		
                let fieldNames = tableInfo.valueFields.split(',');
                let fieldValues = obj["values"].split(',');

                if (fieldNames.length !== fieldValues.length) {
                    throw new Error(`unmatch number of fields, expected ${fieldNames.length} but got ${fieldValues.length}`);
                }

                let entry = new Entry();
                for (let index in fieldNames) {
                    entry.put(fieldNames[index], fieldValues[index]);
                }

                crudService.update(table, entry, ret).then(value=>{
			console.log(value)
			if(value != "0"){
				console.log("update successfuuly")	
			}	
		});
            });
        })
    }
}

exports.route = route
